export type Scores = {
    scoreID: string;
    kills: Number;
    assists: Number;
    deaths: Number;
}